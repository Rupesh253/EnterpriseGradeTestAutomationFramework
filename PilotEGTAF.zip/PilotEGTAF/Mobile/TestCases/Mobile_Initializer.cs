using PilotEGTAF.Common;
using PilotEGTAF.Common.Concretes;

namespace PilotEGTAF.Mobile.TestCases;

[SetUpFixture]
public class Mobile_Initializer
{

    [OneTimeSetUp]
    public void Mobile_Setup()
    {
        GlobalHelper.Print($"_____________________________________________________________________________________________");
        GlobalHelper.Print($"___📱📱📱📱📱📱📱📱📱📱📱📱📱📱📱📱MOBILE📱📱📱📱📱📱📱📱📱📱📱📱📱📱📱📱");
        GlobalHelper.Print($"[SetUpFixture]Mobile_Initializer.cs>Mobile_Setup()");
        GlobalHelper.Print($"✅Created TestCycle");
        GlobalHelper.Print($"✅Fetched TestCases");
        GlobalHelper.Print($"🔗Linked fetched testcases to the created testcycle");
    }

    [OneTimeTearDown]
    public void Mobile_TearDown()
    {
        GlobalHelper.Print($"[SetUpFixture]Mobile_Initializer.cs>Mobile_TearDown()");
        Publisher publisher = new Publisher();
        publisher.Publish2Jira();
        publisher.Publish2Teams();
        GlobalHelper.Print($"___📱📱📱📱📱📱📱📱📱📱📱📱📱📱📱📱MOBILE📱📱📱📱📱📱📱📱📱📱📱📱📱📱📱📱");
        GlobalHelper.Print($"_____________________________________________________________________________________________");
    }

}