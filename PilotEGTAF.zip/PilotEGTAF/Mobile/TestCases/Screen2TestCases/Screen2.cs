using PilotEGTAF.Common;
using PilotEGTAF.Mobile.TestScreens.Screen2;

namespace PilotEGTAF.Mobile.TestCases;

[TestFixture]
public class Screen2TestCases
{
    Screen2 screen2;

    [OneTimeSetUp]
    public void ClassSetup()
    {
        screen2 = new Screen2();
         GlobalHelper.Print($"___✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨SCREEN2✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨");
        GlobalHelper.Print($"___ \t🧪 [TestFixture][OneTimeSetUp]Screen2TestCases.cs/ClassSetup()>INITIALIZED Screen2");
        GlobalHelper.Print($"___ \t ⏱️ Started TestClass Timer");
    }
    [SetUp]
    public void TestSetup()
    {
        GlobalHelper.Print($"------------------------------------------------------------------");
        GlobalHelper.Print($"\t🧪 [TestFixture][SetUp]Screen2TestCases.cs/TestSetup()");
        GlobalHelper.Print($"\t ⏱️ Started TestMethod Timer");
        GlobalHelper.Print($"🎥✅ Started Screen recording");
    }
    [Test]
    public void Test1()
    {
        GlobalHelper.Print($"\t🧪[TestFixture][Test]Screen2TestCases.cs/Test1()>CALLED Screen2.Screen2_Method1()");
        screen2.Screen2_Method1();
        Assert.Pass();
    }
    [Test]
    public void Test2()
    {
        GlobalHelper.Print($"\t🧪 [TestFixture][Test]Screen2TestCases.cs/Test1()>CALLED Screen2.Screen2_Method2()");
        screen2.Screen2_Method2();
        Assert.Pass();
    }
    [TearDown]
    public void TestTearDown()
    {
        GlobalHelper.Print($"\t🧪 [TestFixture][TearDown]Screen2TestCases.cs/TestTearDown()");
        GlobalHelper.Print($"\t ⏱️ Stopped TestMethod Timer and Calculated time taken for testcase");
        GlobalHelper.Print($"✅ Stored the testresult info into ExecutionTestCases.json");
        GlobalHelper.Print($"\t🎥❌Stopped Screen recording and based on testcase result: Pass(Delete Immediately for Storage Optimization) or Fail(Store it for defect)");
        GlobalHelper.Print($"------------------------------------------------------------------");
    }
    [OneTimeTearDown]
    public void ClassTearDown()
    {
        GlobalHelper.Print($"___ \t ⏱️ Stopped TestClass Timer and Calculated time taken for testclass");
        GlobalHelper.Print($"___ \t🧪 [TestFixture][OneTimeTearDown]Screen2TestCases.cs/ClassTearDown()>DESTROYED Screen2");
         GlobalHelper.Print($"___✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨SCREEN2✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨");
    }
}

