using PilotEGTAF.Common;
using PilotEGTAF.Mobile.TestScreens;

namespace PilotEGTAF.Mobile.TestCases;

[TestFixture]
public class Screen1TestCases
{
    Screen1 screen1;

    [OneTimeSetUp]
    public void ClassSetup()
    {
        screen1 = new Screen1();
         GlobalHelper.Print($"___✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨SCREEN1✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨");
        GlobalHelper.Print($"\t🧪 [TestFixture][OneTimeSetUp]Screen1TestCases.cs/ClassSetup()>INITIALIZED Screen1");
        GlobalHelper.Print($"\t ⏱️ Started TestClass Timer");
    }
    [SetUp]
    public void TestSetup()
    {
        GlobalHelper.Print($"------------------------------------------------------------------");
        GlobalHelper.Print($"\t🧪 [TestFixture][SetUp]Screen1TestCases.cs/TestSetup()");
        GlobalHelper.Print($"\t ⏱️ Started TestMethod Timer");
        GlobalHelper.Print($"🎥✅ Started Screen recording");
    }
    [Test]
    public void Test1()
    {
        GlobalHelper.Print($"\t🧪[TestFixture][Test]Screen1TestCases.cs/Test1()>CALLED Screen1.Screen1_Method1()");
        screen1.Screen1_Method1();
        Assert.Pass();
    }
    [Test]
    public void Test2()
    {
        GlobalHelper.Print($"\t🧪 [TestFixture][Test]Screen1TestCases.cs/Test1()>CALLED Screen1.Screen1_Method2()");
        screen1.Screen1_Method2();
        Assert.Pass();
    }
    [TearDown]
    public void TestTearDown()
    {
        GlobalHelper.Print($"\t🧪 [TestFixture][TearDown]Screen1TestCases.cs/TestTearDown()");
        GlobalHelper.Print($"\t ⏱️ Stopped TestMethod Timer and Calculated time taken for testcase");
        GlobalHelper.Print($"✅ Stored the testresult info into ExecutionTestCases.json");
        GlobalHelper.Print($"\t🎥❌Stopped Screen recording and based on testcase result: Pass(Delete Immediately for Storage Optimization) or Fail(Store it for defect)");
        GlobalHelper.Print($"------------------------------------------------------------------");
    }
    [OneTimeTearDown]
    public void ClassTearDown()
    {
        GlobalHelper.Print($"\t ⏱️ Stopped TestClass Timer and Calculated time taken for testclass");
        GlobalHelper.Print($"\t🧪 [TestFixture][OneTimeTearDown]Screen1TestCases.cs/ClassTearDown()>DESTROYED Screen1");
         GlobalHelper.Print($"___✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨SCREEN1✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨");
    }
}

