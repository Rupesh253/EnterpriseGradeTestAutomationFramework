using PilotEGTAF.Common;

namespace PilotEGTAF.Mobile.TestScreens;

public class Screen1
{
    public string Screen1_Prop1 { get; set; } = "Screen1Prop1Value";
    public string Screen1_Prop2 { get; set; } = "Screen1Prop2Value";

    public Screen1(){
        GlobalHelper.Print($"\t 🏭ScreenFactory with SOM for Screen1");
    }

    public void Screen1_Method1()
    {
        GlobalHelper.Print($"🎮Screen1.cs/Screen1_Method1()>USED Screen1_Prop1:{Screen1_Prop1}");
        GlobalHelper.Print($"💽 Read from TestData/Screen1Data/Screen1Data.json and Printed 📈");
    }

    public void Screen1_Method2()
    {
        GlobalHelper.Print($"🎨Screen1.cs>Screen1_Method2()>USED Screen1_Prop2:{Screen1_Prop2}");
          GlobalHelper.Print($"💽 Read from TestData/Screen1Data/Screen1Data.json and Printed 📈");
    }

}