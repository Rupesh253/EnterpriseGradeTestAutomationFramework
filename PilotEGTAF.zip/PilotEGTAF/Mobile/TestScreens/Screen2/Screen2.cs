using PilotEGTAF.Common;

namespace PilotEGTAF.Mobile.TestScreens.Screen2;

public class Screen2
{

    public string Screen2_Prop1 { get; set; } = "Screen2Prop1Value";
    public string Screen2_Prop2 { get; set; } = "Screen2Prop2Value";

    public Screen2()
    {
        GlobalHelper.Print($"\t 🏭ScreenFactory with SOM for Screen2");
    }

    public void Screen2_Method1()
    {
        GlobalHelper.Print($"🎮Screen2.cs/Screen2_Method1()>USED Screen2_Prop1:{Screen2_Prop1}");
        GlobalHelper.Print($"💽 Read from TestData/Screen2Data/Screen2Data.json and Printed 📈");
    }

    public void Screen2_Method2()
    {
        GlobalHelper.Print($"🎨Screen2.cs>Screen2_Method2()>USED Screen2_Prop2:{Screen2_Prop2}");
        GlobalHelper.Print($"💽 Read from TestData/Screen2Data/Screen2Data.json and Printed 📈");
    }

}