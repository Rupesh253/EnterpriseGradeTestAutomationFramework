using System.Text;
using Microsoft.VisualStudio.TestPlatform.ObjectModel;
using NUnit.Framework.Interfaces;
using PilotEGTAF.Common;
using PilotEGTAF.Common.Concretes;
using PilotEGTAF.Web.TestPages.Page1;
using TestCase = PilotEGTAF.Common.Concretes.TestCase;

namespace PilotEGTAF.Web.TestCases;

[TestFixture]
public class Page1TestCases
{
    Page1 page;
    TestCase testcase;
    TestCycle testCycle;
    Defect defect;

    [OneTimeSetUp]
    public void ClassSetup()
    {
        GlobalHelper.Print($"___✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨SCREEN1✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨");
        page = new Page1();
        GlobalHelper.Print($"___ \t🧪 [TestFixture][OneTimeSetUp]Page1TestCases.cs/ClassSetup()>INITIALIZED Page1");
        GlobalHelper.Print($"___ \t ⏱️ Started TestClass Timer");
    }
    [SetUp]
    public void TestSetup()
    {
        GlobalHelper.Print($"------------------------------------------------------------------");
        GlobalHelper.Print($"\t🧪 [TestFixture][SetUp]Page1TestCases.cs/TestSetup()");
        GlobalHelper.Print($"\t ⏱️ Started TestMethod Timer");
        GlobalHelper.Print($"🎥✅ Started Screen recording");
    }
    [Test]
    public void Test1()
    {
        GlobalHelper.Print($"\t🧪[TestFixture][Test]Page1TestCases.cs/Test1()>CALLED Page1.Page1_Method1()");
        page.Page1_Method1();
        Assert.Pass();
    }
    [Test]
    public void Test2()
    {
        GlobalHelper.Print($"\t🧪 [TestFixture][Test]Page1TestCases.cs/Test1()>CALLED Page1.Page1_Method2()");
        page.Page1_Method2();
        Assert.Pass();
    }
    [TearDown]
    public void TestTearDown()
    {
        GlobalHelper.Print($"\t🧪 [TestFixture][TearDown]Page1TestCases.cs/TestTearDown()");
        GlobalHelper.Print($"\t ⏱️ Stopped TestMethod Timer and Calculated time taken for testcase");
        GlobalHelper.Print($"✅ Stored the testresult info into ExecutionTestCases.json");
        GlobalHelper.Print($"\t🎥❌Stopped Screen recording and based on testcase result: Pass(Delete Immediately for Storage Optimization) or Fail(Store it for defect)");
        if (TestContext.CurrentContext.Result.Outcome.Status == TestStatus.Passed)
        {

        }
        else
        {
            string title = TestContext.CurrentContext.Test.MethodName;
            StringBuilder prepareErrorMessage = new StringBuilder();
            prepareErrorMessage.Append(string.Format("Top Stacktrace:\n{0}", TestContext.CurrentContext.Result.StackTrace));
            prepareErrorMessage.AppendLine(string.Format("Top Message:\n{0}", TestContext.CurrentContext.Result.Message));
            if (TestContext.CurrentContext.Result.Assertions.ToList().Count > 1)
            {
                foreach (var item in TestContext.CurrentContext.Result.Assertions)
                {
                    prepareErrorMessage.AppendLine($"Assertion Status: {item.Status}");
                    prepareErrorMessage.AppendLine($"Assertion Message: {item.Message}");
                    prepareErrorMessage.AppendLine($"Assertion StackTrace: {item.StackTrace}");
                }
            }
            string description = prepareErrorMessage.ToString();
            string evidence = @"C:\Users\RUPESHKUMARSOMALA\source\repos\XploreAutomationIntegrations\XploreAutomationIntegrations\video.mp4";
            long defectID = defect.RaiseDefect(title, description, evidence);
            long executionID = 53535353; //get from the json
            defect.LinkDefect2TestCase(executionID, defectID);
        }
        GlobalHelper.Print($"------------------------------------------------------------------");
    }
    [OneTimeTearDown]
    public void ClassTearDown()
    {
        GlobalHelper.Print($"___ \t ⏱️ Stopped TestClass Timer and Calculated time taken for testclass");
        GlobalHelper.Print($"___ \t🧪 [TestFixture][OneTimeTearDown]Page1TestCases.cs/ClassTearDown()>DESTROYED Page1");
        GlobalHelper.Print($"___✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨PAGE2✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨");
    }
}
