using PilotEGTAF.Common;
using PilotEGTAF.Web.TestPages.Page2;

namespace PilotEGTAF.Web.TestCases;

[TestFixture]
public class Page2TestCases
{
    Page2 page;

    [OneTimeSetUp]
    public void ClassSetup()
    {
        page = new Page2();
        GlobalHelper.Print($"___✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨PAGE2✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨");
        GlobalHelper.Print($"___ \t🧪 [TestFixture][OneTimeSetUp]Page2TestCases.cs/ClassSetup()>INITIALIZED Page2");
        GlobalHelper.Print($"___ \t ⏱️ Started TestClass Timer");
    }
    [SetUp]
    public void TestSetup()
    {
        GlobalHelper.Print($"------------------------------------------------------------------");
        GlobalHelper.Print($"\t🧪 [TestFixture][SetUp]Page2TestCases.cs/TestSetup()");
        GlobalHelper.Print($"\t ⏱️ Started TestMethod Timer");
        GlobalHelper.Print($"🎥✅ Started Screen recording");
    }
    [Test]
    public void Test1()
    {
        GlobalHelper.Print($"\t🧪 [TestFixture][Test]Page2TestCases.cs/Test1()>CALLED Page2.Page2_Method1()");
        page.Page2_Method1();
        Assert.Pass();
    }
    [Test]
    public void Test2()
    {
        GlobalHelper.Print($"\t🧪 [TestFixture][Test]Page2TestCases.cs/Test1()>CALLED Page2.Page2_Method2()");
        page.Page2_Method2();
        Assert.Pass();
    }
    [TearDown]
    public void TestTearDown()
    {
        GlobalHelper.Print($"\t🧪 [TestFixture][TearDown]Page2TestCases.cs/TestTearDown()");
        GlobalHelper.Print($"\t ⏱️ Stopped TestMethod Timer and Calculated time taken for testcase");
        GlobalHelper.Print($"✅ Stored the testresult info into ExecutionTestCases.json");
        GlobalHelper.Print($"\t🎥❌ Stopped Screen recording and based on testcase result: Pass(Delete Immediately for Storage Optimization) or Fail(Store it for defect)");
        GlobalHelper.Print($"------------------------------------------------------------------");
    }
    [OneTimeTearDown]
    public void ClassTearDown()
    {
        GlobalHelper.Print($"___ \t ⏱️ Stopped TestClass Timer and Calculated time taken for testclass");
        GlobalHelper.Print($"___ \t🧪 [TestFixture][OneTimeTearDown]Page2TestCases.cs/ClassTearDown()>DESTROYED Page2");
        GlobalHelper.Print($"___✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨PAGE2✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨");
    }
}
