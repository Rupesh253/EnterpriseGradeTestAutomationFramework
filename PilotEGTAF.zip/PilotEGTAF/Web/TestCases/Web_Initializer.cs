using PilotEGTAF.Common;
using PilotEGTAF.Common.Abstractions;
using PilotEGTAF.Common.Concretes;

namespace PilotEGTAF.Web.TestCases;

[SetUpFixture]
public class Web_Initializer
{

    [OneTimeSetUp]
    public void Web_Setup()
    {
        GlobalHelper.Print($"_____________________________________________________________________________________________");
        GlobalHelper.Print($"___ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ WEB 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ ");
        GlobalHelper.Print($"[SetUpFixture]Web_Initializer.cs>Web_Setup()");

        TestCycle testCycle = new TestCycle();
        long testCycleId = testCycle.CreateTestCycle("Web", "Smoke");
        GlobalHelper.Print($"\t ✅ Created TestCycle");

        TestCase testCase = new TestCase();
        List<ITestCase> testCases=testCase.FetchEligibleTestCases("Web", "Smoke");
        GlobalHelper.Print($"\t ✅ Fetched TestCases");

        testCase.AttachTestCases2TestCycle(testCycleId,testCases);
        GlobalHelper.Print($"🔗 Linked fetched testcases to the created testcycle");
    }

    [OneTimeTearDown]
    public void Web_TearDown()
    {
        GlobalHelper.Print($"[SetUpFixture]Web_Initializer.cs>Web_TearDown()");
        Publisher publisher = new Publisher();
        publisher.Publish2Jira();
        publisher.Publish2Teams();
        GlobalHelper.Print($"___ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ WEB 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ 🖥️ ");
        GlobalHelper.Print($"_____________________________________________________________________________________________");
    }

}