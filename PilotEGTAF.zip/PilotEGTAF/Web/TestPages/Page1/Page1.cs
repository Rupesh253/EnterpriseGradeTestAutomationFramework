using PilotEGTAF.Common;

namespace PilotEGTAF.Web.TestPages.Page1;


public class Page1
{
    public string Page1_Prop1 { get; set; } = "Page1Prop1Value";
    public string Page1_Prop2 { get; set; } = "Page1Prop2Value";

    public Page1(){
        GlobalHelper.Print($"\t 🏭PageFactory with POM for Page1");
    }

    public void Page1_Method1()
    {
        GlobalHelper.Print($"🎮Page1.cs/Page1_Method1()>USED Page1_Prop1:{Page1_Prop1}");
        GlobalHelper.Print($"💽 Read from TestData/Page1Data/Page1Data.json and Printed 📈");
    }

    public void Page1_Method2()
    {
        GlobalHelper.Print($"🎨Page1.cs>Page1_Method2()>USED Page1_Prop2:{Page1_Prop2}");
          GlobalHelper.Print($"💽 Read from TestData/Page1Data/Page1Data.json and Printed 📈");
    }

}