using PilotEGTAF.Common;

namespace PilotEGTAF.Web.TestPages.Page2;


public class Page2
{
    public string Page2_Prop1 { get; set; } = "Page2Prop1Value";
    public string Page2_Prop2 { get; set; } = "Page2Prop2Value";

    public Page2()
    {
        GlobalHelper.Print($"\t 🏭PageFactory with POM for Page2");
    }

    public void Page2_Method1()
    {
        GlobalHelper.Print($"🎮Page2.cs>Page2_Method1()>USED Page2_Prop1:{Page2_Prop1}");
        GlobalHelper.Print($"💾 Read from TestData/Page2Data/Page2Data.json and Printed 📉");
    }

    public void Page2_Method2()
    {
        GlobalHelper.Print($"🎨Page2.cs>Page2_Method2()>USED Page2_Prop2:{Page2_Prop2}");
        GlobalHelper.Print($"💾 Read from TestData/Page2Data/Page2Data.json and Printed 📉");
    }

}