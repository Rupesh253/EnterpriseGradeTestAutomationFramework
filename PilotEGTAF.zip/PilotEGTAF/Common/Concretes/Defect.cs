using PilotEGTAF.Common.Abstractions;

namespace PilotEGTAF.Common.Concretes;

public class Defect : IDefect
{
    public long RaiseDefect(string title, string description, string evidence)
    {
        GlobalHelper.Print($"Raised a defect with title:{title}, description:{description},evidence:{evidence} and returning bugID");
        return 12345;
    }
    public void LinkDefect2TestCase(long executionId, long defectID)
    {
        GlobalHelper.Print($"Linked defect:{defectID} to the testcase:{executionId}");
    }
}
