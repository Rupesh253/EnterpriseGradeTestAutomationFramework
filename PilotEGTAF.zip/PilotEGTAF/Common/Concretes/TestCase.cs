using PilotEGTAF.Common.Abstractions;

namespace PilotEGTAF.Common.Concretes;

public class TestCase : ITestCase
{
    public void AttachTestCases2TestCycle(long testCycleId, List<ITestCase> testcases)
    {
        GlobalHelper.Print($"Attaching testcases for testcycleId:{testCycleId}");
    }

    public List<ITestCase> FetchEligibleTestCases(string moduleName, string testType)
    {
        GlobalHelper.Print($"Fetching testcases for module:{moduleName},testType:{testType} and returning list of testcases");
        return new List<ITestCase>() { };
    }
}
