using PilotEGTAF.Common.Abstractions;

namespace PilotEGTAF.Common.Concretes;

public class Publisher : IPublisher
{
    public void Publish2Jira()
    {
         GlobalHelper.Print($"\t📊Bulkpost/Published testresults from PublisedTestCasesStatus.json to Jira");
    }

    public void Publish2Teams()
    {
         GlobalHelper.Print($"\t📊Bulkpost/Published testresults from PublisedTestCasesStatus.json to 🪝MS Teams");
    }
}
