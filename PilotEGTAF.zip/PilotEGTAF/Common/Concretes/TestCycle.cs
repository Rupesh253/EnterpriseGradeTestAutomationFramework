using PilotEGTAF.Common.Abstractions;

namespace PilotEGTAF.Common.Concretes;

public class TestCycle : ITestCycle
{
    public long CreateTestCycle(string moduleName, string testType)
    {
        GlobalHelper.Print($"Creating testcycle for module:{moduleName},testType:{testType} and returning testCycleID");
        return 111111;
    }

    public void UpdateTestCycle(string oldName, int testCycleId)
    {
        string newName= string.Format($"[MODIFIED]{oldName}");
        GlobalHelper.Print($"Updated testcycle name as {newName}");
    }
}
