namespace PilotEGTAF.Common.Abstractions;

public interface IDefect
{   
    //Few props
    long RaiseDefect(string title, string description, string evidence);
    void LinkDefect2TestCase(long executionId, long defectID);
}
