namespace PilotEGTAF.Common.Abstractions;

public interface IPublisher
{
    void Publish2Jira();
    void Publish2Teams();
}
