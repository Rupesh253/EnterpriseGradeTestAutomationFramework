namespace PilotEGTAF.Common.Abstractions;

public interface ITestCase
{   //Few props
    List<ITestCase> FetchEligibleTestCases(string module, string testType);
    void AttachTestCases2TestCycle(long testCycleId, List<ITestCase> testcases);
}
