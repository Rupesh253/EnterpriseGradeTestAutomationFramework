namespace PilotEGTAF.Common.Abstractions;

public interface ITestCycle
{
    //Few props
    long CreateTestCycle(string moduleName,string testType);
    void UpdateTestCycle(string newName, int testCycleId);
}
