using System.Reflection;
using log4net;
using log4net.Config;


namespace PilotEGTAF.Common;

public static class GlobalHelper
{
    private static readonly log4net.ILog logger = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

    public static void Print(string message)
    {
        log4net.Config.XmlConfigurator.Configure(new FileInfo(string.Format("{0}.{1}", Assembly.GetExecutingAssembly().Location, "config")));
        //XmlConfigurator.Configure();
        foreach (char c in message)
        {
            Console.Write($"{c}");
        }
        Console.WriteLine();
        logger.Info($"|{message}");
    }


}
