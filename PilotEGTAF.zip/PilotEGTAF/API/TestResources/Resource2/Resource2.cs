using PilotEGTAF.Common;

namespace PilotEGTAF.API.TestResources.Resource2;



public class Resource2
{
    public string Resource2_Prop1 { get; set; } = "Resource2Prop1Value";
    public string Resource2_Prop2 { get; set; } = "Resource2Prop2Value";

    public Resource2(){
        GlobalHelper.Print($"\t 🏭ResourceFactory with ROM for Resource2");
    }

    public void Resource2_Method1()
    {
        GlobalHelper.Print($"🎮Resource2.cs/Resource2_Method1()>USED Resource2_Prop1:{Resource2_Prop1}");
        GlobalHelper.Print($"💽 Read from TestData/Resource2Data/Resource2Data.json and Printed 📈");
    }

    public void Resource2_Method2()
    {
        GlobalHelper.Print($"🎨Resource2.cs>Resource2_Method2()>USED Resource2_Prop2:{Resource2_Prop2}");
          GlobalHelper.Print($"💽 Read from TestData/Resource2Data/Resource2Data.json and Printed 📈");
    }

}