using PilotEGTAF.Common;

namespace PilotEGTAF.API.TestResources.Resource1;



public class Resource1
{
    public string Resource1_Prop1 { get; set; } = "Resource1Prop1Value";
    public string Resource1_Prop2 { get; set; } = "Resource1Prop2Value";

    public Resource1(){
        GlobalHelper.Print($"\t 🏭ResourceFactory with ROM for Resource1");
    }

    public void Resource1_Method1()
    {
        GlobalHelper.Print($"🎮Resource1.cs/Resource1_Method1()>USED Resource1_Prop1:{Resource1_Prop1}");
        GlobalHelper.Print($"💽 Read from TestData/Resource1Data/Resource1Data.json and Printed 📈");
    }

    public void Resource1_Method2()
    {
        GlobalHelper.Print($"🎨Resource1.cs>Resource1_Method2()>USED Resource1_Prop2:{Resource1_Prop2}");
          GlobalHelper.Print($"💽 Read from TestData/Resource1Data/Resource1Data.json and Printed 📈");
    }

}