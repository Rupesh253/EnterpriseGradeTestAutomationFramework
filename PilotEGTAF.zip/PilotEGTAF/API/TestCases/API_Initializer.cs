using PilotEGTAF.Common;

namespace PilotEGTAF.API.TestCases;

[SetUpFixture]
public class API_Initializer
{

    [OneTimeSetUp]
    public void API_Setup()
    {  GlobalHelper.Print($"_____________________________________________________________________________________________");
        GlobalHelper.Print($"___🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨API🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨");
        GlobalHelper.Print($"[SetUpFixture]API_Initializer.cs>API_Setup()");
        GlobalHelper.Print($"✅Created TestCycle");
        GlobalHelper.Print($"✅Fetched TestCases");
        GlobalHelper.Print($"🔗Linked fetched testcases to the created testcycle");
    }

    [OneTimeTearDown]
    public void API_TearDown()
    {
        GlobalHelper.Print($"[SetUpFixture]API_Initializer.cs>API_TearDown()");
        GlobalHelper.Print($"\t📊Bulkpost/Published testresults from PublisedTestCasesStatus.json to Jira");
        GlobalHelper.Print($"\t📊Bulkpost/Published testresults from PublisedTestCasesStatus.json to 🪝MS Teams");
        GlobalHelper.Print($"___🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨API🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨🧨");
        GlobalHelper.Print($"_____________________________________________________________________________________________");
    }

}
